import kfa.model.Book;
import kfa.model.DVD;
import kfa.model.LibraryItem;
import kfa.model.LibraryUtils;
import kfa.model.Magazine;
import kfa.service.LibraryCatalogue;
import java.util.ArrayList;
import kfa.service.BorrowManager;


public class Main {

    public static void main(String[] args) {

        System.out.println("===== SECTION A =====");


        // A1: Test sanitizeTitle()

        System.out.println("\n--- A1 ---");

        System.out.println(
                LibraryUtils.sanitizeTitle(
                        " the GREAT gatsby "
                )
        );

        System.out.println(
                LibraryUtils.sanitizeTitle(
                        "   JAVA    PROGRAMMING "
                )
        );

        System.out.println(
                LibraryUtils.sanitizeTitle(
                        "  clean    CODE   "
                )
        );


        // A2: Create a book

        Book book = new Book(
                "Clean Code",
                "Robert Martin",
                "B001",
                850
        );


        // A2: Receipt

        System.out.println("\n--- A2 Receipt ---");

        System.out.println(
                LibraryUtils.generateReceiptText(
                        "Anjila Bhandari",
                        book
                )
        );


        // A2: == versus equals()

        System.out.println("--- == versus equals() ---");

        String isbn1 =
                new String("1234567890123");

        String isbn2 =
                new String("1234567890123");

        System.out.println(
                "isbn1 == isbn2: "
                        + (isbn1 == isbn2)
        );

        System.out.println(
                "isbn1.equals(isbn2): "
                        + isbn1.equals(isbn2)
        );
        System.out.println("\n===== SECTION B1 =====");

// Create 5 shelves with 10 slots each.
        String[][] shelves = new String[5][10];

// Make every slot empty.
        for (int i = 0; i < shelves.length; i++) {

            for (int j = 0; j < shelves[i].length; j++) {

                shelves[i][j] = "";
            }
        }


// Place some books on the shelves.

        int[] position1 =
                LibraryUtils.placeOnShelf(
                        shelves,
                        "B001"
                );

        System.out.println(
                "B001 placed at shelf "
                        + position1[0]
                        + ", slot "
                        + position1[1]
        );


        int[] position2 =
                LibraryUtils.placeOnShelf(
                        shelves,
                        "B002"
                );

        System.out.println(
                "B002 placed at shelf "
                        + position2[0]
                        + ", slot "
                        + position2[1]
        );


        int[] position3 =
                LibraryUtils.placeOnShelf(
                        shelves,
                        "B003"
                );

        System.out.println(
                "B003 placed at shelf "
                        + position3[0]
                        + ", slot "
                        + position3[1]
        );


// Print the entire shelf grid.

        System.out.println("\nShelf layout:");

        LibraryUtils.printShelves(shelves);

        // ==========================================
// SECTION B2
// ==========================================

        System.out.println("\n===== SECTION B2 =====");


// Create at least 5 books.

        Book book1 = new Book(
                "Clean Code",
                "Robert Martin",
                "B001",
                850
        );

        Book book2 = new Book(
                "Effective Java",
                "Joshua Bloch",
                "B002",
                1200
        );

        Book book3 = new Book(
                "Java Basics",
                "John Smith",
                "B003",
                650
        );

        Book book4 = new Book(
                "Head First Java",
                "Kathy Sierra",
                "B004",
                950
        );

        Book book5 = new Book(
                "Python Basics",
                "Mark Lee",
                "B005",
                700
        );


        Book[] books = {
                book1,
                book2,
                book3,
                book4,
                book5
        };


// ------------------------------------------
// Find most expensive
// ------------------------------------------

        System.out.println("\nMost expensive book:");

        Book expensive =
                LibraryUtils.findMostExpensive(books);

        System.out.println(expensive);


// ------------------------------------------
// Before reverse
// ------------------------------------------

        System.out.println("\nBefore reverse:");

        for (Book bookss: books) {
            System.out.println(bookss);
        }


// ------------------------------------------
// Reverse
// ------------------------------------------

        LibraryUtils.reverseInPlace(books);


// ------------------------------------------
// After reverse
// ------------------------------------------

        System.out.println("\nAfter reverse:");

        for (Book bookss : books) {
            System.out.println(bookss);
        }
        // ==========================================
// SECTION C1
// ==========================================

        System.out.println("\n===== SECTION C1 =====");


// Create catalogue.

        LibraryCatalogue catalogue =
                new LibraryCatalogue();


// Add different types of LibraryItem.

        catalogue.addItem(book1);

        catalogue.addItem(book2);

        catalogue.addItem(book3);

        catalogue.addItem(book4);

        catalogue.addItem(book5);


// Print complete catalogue.

        System.out.println("\nComplete catalogue:");

        catalogue.printCatalogue();


// Search by title.

        System.out.println(
                "\nSearch results for 'Java':"
        );

        ArrayList<LibraryItem> results =
                catalogue.searchByTitle("Java");

        for (LibraryItem item : results) {

            System.out.println(item);
        }


// Remove a book.

        System.out.println(
                "\nRemoving B003..."
        );

        boolean removed =
                catalogue.removeItem("B003");

        System.out.println(
                "Was item removed? "
                        + removed
        );


// Print catalogue again.

        System.out.println(
                "\nCatalogue after removal:"
        );

        catalogue.printCatalogue();

        // ==========================================
// SECTION C2
// ==========================================

        System.out.println("\n===== SECTION C2 =====");


// ------------------------------------------
// Sort by price
// ------------------------------------------

        catalogue.sortByPrice();

        System.out.println(
                "\nCatalogue sorted by price:"
        );

        catalogue.printCatalogue();


// ------------------------------------------
// Sort by title
// ------------------------------------------

        catalogue.sortByTitle();

        System.out.println(
                "\nCatalogue sorted by title:"
        );

        catalogue.printCatalogue();
        // ==========================================
// SECTION C3
// ==========================================

        System.out.println("\n===== SECTION C3 =====");


// Remove an item.

        System.out.println(
                "\nRemoving B004..."
        );

        boolean removedB004 =
                catalogue.removeItem("B004");

        System.out.println(
                "Was item removed? "
                        + removedB004
        );


// Show catalogue after removal.

        System.out.println(
                "\nCatalogue after removing B004:"
        );

        catalogue.printCatalogue();


// Undo the removal.

        System.out.println(
                "\nUndoing last removal..."
        );

        catalogue.undoRemove();


// Show catalogue after undo.

        System.out.println(
                "\nCatalogue after undo:"
        );

        catalogue.printCatalogue();


// Try undoing again.

        System.out.println(
                "\nTrying another undo..."
        );

        catalogue.undoRemove();
        // ==========================================
// SECTION D1
// ==========================================

        System.out.println("\n===== SECTION D1 =====");


        BorrowManager borrowManager =
                new BorrowManager();


// ------------------------------------------
// Normal borrow
// ------------------------------------------

        boolean firstBorrow =
                borrowManager.borrow("B001");

        System.out.println(
                "Borrow B001: "
                        + (firstBorrow
                        ? "Successful"
                        : "Already borrowed")
        );


// ------------------------------------------
// Attempt double-borrow
// ------------------------------------------

        boolean secondBorrow =
                borrowManager.borrow("B001");

        System.out.println(
                "Borrow B001 again: "
                        + (secondBorrow
                        ? "Successful"
                        : "Already borrowed")
        );


// ------------------------------------------
// Return book
// ------------------------------------------

        boolean returned =
                borrowManager.returnBook("B001");

        System.out.println(
                "Return B001: "
                        + (returned
                        ? "Successful"
                        : "ISBN was not borrowed")
        );
        // ==========================================
// SECTION D2
// ==========================================

        System.out.println("\n===== SECTION D2 =====");


        BorrowManager indexManager =
                new BorrowManager();


// Add books to the ISBN index.

        indexManager.addBook(book1);
        indexManager.addBook(book2);
        indexManager.addBook(book3);
        indexManager.addBook(book4);
        indexManager.addBook(book5);


// Search using ISBN.

        System.out.println(
                "\nSearching for ISBN B002:"
        );

        Book foundBook =
                indexManager.findByIsbn("B002");

        if (foundBook != null) {

            System.out.println(foundBook);

        } else {

            System.out.println(
                    "Book not found."
            );
        }


// Search for an ISBN that does not exist.

        System.out.println(
                "\nSearching for ISBN B999:"
        );

        Book missingBook =
                indexManager.findByIsbn("B999");

        if (missingBook != null) {

            System.out.println(missingBook);

        } else {

            System.out.println(
                    "Book not found."
            );
        }
        // ==========================================
// SECTION D3
// ==========================================

        System.out.println("\n===== SECTION D3 =====");


        String[] borrowLog = {

                "Clean Code",
                "Effective Java",
                "Clean Code",
                "Python Basics",
                "Clean Code",
                "Head First Java",
                "Effective Java",
                "Clean Code",
                "Python Basics",
                "Effective Java"
        };


        BorrowManager reportManager =
                new BorrowManager();


        reportManager.mostBorrowedReport(
                borrowLog
        );


    }



}

