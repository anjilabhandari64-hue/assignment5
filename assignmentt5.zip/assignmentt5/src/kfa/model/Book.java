package kfa.model;

public class Book extends LibraryItem implements Renewable {

    private String author;

    public Book(String title, String author, String isbn, double price) {
        super(title, isbn, price);
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @Override
    public int getLendingPeriodDays() {
        return 14;
    }

    @Override
    public void renew(int extraDays) {
        System.out.println(
                "Book renewed for an additional " + extraDays + " days."
        );
    }

    @Override
    public String toString() {
        String status = isAvailable() ? "Available" : "Not Available";

        return String.format(
                "[Book] %s by %s — Rs %.2f (%s)",
                getTitle(), author, getPrice(), status
        );
    }
}