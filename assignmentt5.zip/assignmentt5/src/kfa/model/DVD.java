package kfa.model;

public class DVD extends LibraryItem implements Renewable {

    private int durationMinutes;

    public DVD(String title, String isbn, double price, int durationMinutes) {
        super(title, isbn, price);
        this.durationMinutes = durationMinutes;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    @Override
    public int getLendingPeriodDays() {
        return 5;
    }

    @Override
    public void renew(int extraDays) {
        System.out.println(
                "DVD renewed for an additional " + extraDays + " days."
        );
    }

    @Override
    public String toString() {
        String status = isAvailable() ? "Available" : "Not Available";

        return String.format(
                "[DVD] %s — %d minutes (%s)",
                getTitle(), durationMinutes, status
        );
    }
}