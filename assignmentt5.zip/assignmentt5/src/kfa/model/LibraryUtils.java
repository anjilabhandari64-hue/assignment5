package kfa.model;

public class LibraryUtils {


    public static String sanitizeTitle(String raw) {

        // Remove spaces from the beginning and end.
        raw = raw.trim();

        // Split the title into separate words.
        String[] words = raw.split(" ");

        StringBuilder result = new StringBuilder();

        for (String word : words) {

            // Ignore empty strings caused by multiple spaces.
            if (word.length() == 0) {
                continue;
            }

            // Convert the word to lowercase first.
            word = word.toLowerCase();

            // Capitalise the first letter.
            String formattedWord =
                    word.substring(0, 1).toUpperCase()
                            + word.substring(1);

            // Add a space between words.
            if (result.length() > 0) {
                result.append(" ");
            }

            result.append(formattedWord);
        }

        return result.toString();
    }



    public static String generateReceiptText(
            String memberName,
            LibraryItem item) {

        StringBuilder receipt =
                new StringBuilder();

        receipt.append("================================\n");
        receipt.append("        KFA LIBRARY RECEIPT\n");
        receipt.append("================================\n");

        receipt.append("Member Name: ")
                .append(memberName)
                .append("\n");

        receipt.append("Item Title: ")
                .append(item.getTitle())
                .append("\n");

        receipt.append("Due Date: [DATE PLACEHOLDER]\n");

        receipt.append("--------------------------------\n");

        return receipt.toString();
    }
    public static int[] placeOnShelf(
            String[][] shelves,
            String isbn) {

        // Search shelf by shelf and slot by slot.
        for (int shelf = 0;
             shelf < shelves.length;
             shelf++) {

            for (int slot = 0;
                 slot < shelves[shelf].length;
                 slot++) {

                // Empty slot found.
                if (shelves[shelf][slot].equals("")) {

                    shelves[shelf][slot] = isbn;

                    // Return shelf number and slot number.
                    return new int[]{shelf, slot};
                }
            }
        }

        // No empty slot was found.
        return new int[]{-1, -1};
    }
    public static void printShelves(
            String[][] shelves) {

        for (int shelf = 0;
             shelf < shelves.length;
             shelf++) {

            System.out.print(
                    "Shelf " + shelf + ": "
            );

            for (int slot = 0;
                 slot < shelves[shelf].length;
                 slot++) {

                if (shelves[shelf][slot].equals("")) {
                    System.out.print("[Empty] ");
                } else {
                    System.out.print(
                            "[" + shelves[shelf][slot] + "] "
                    );
                }
            }

            System.out.println();
        }
    }
    public static Book findMostExpensive(
            Book[] books) {

        Book mostExpensive = books[0];

        // Compare every book with the current
        // most expensive book.
        for (int i = 1;
             i < books.length;
             i++) {

            if (books[i].getPrice()
                    > mostExpensive.getPrice()) {

                mostExpensive = books[i];
            }
        }

        return mostExpensive;
    }
    public static void reverseInPlace(
            Book[] books) {

        int left = 0;
        int right = books.length - 1;

        while (left < right) {

            // Swap the two elements.
            Book temp = books[left];

            books[left] = books[right];

            books[right] = temp;

            left++;
            right--;
        }
    }


}