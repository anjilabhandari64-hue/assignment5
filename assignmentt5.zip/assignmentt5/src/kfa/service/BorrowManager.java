package kfa.service;

import kfa.model.Book;

import java.util.HashSet;
import java.util.HashMap;

public class BorrowManager {

    // Stores ISBNs of books that are currently borrowed.
    private HashSet<String> currentlyBorrowed;
    // Maps each ISBN directly to its Book object.
    private HashMap<String, Book> isbnIndex;


    // Constructor
    public BorrowManager() {

        currentlyBorrowed =
                new HashSet<>();

        isbnIndex =
                new HashMap<>();
    }
    // ==========================================
// SECTION D2: addBook()
// ==========================================

    public void addBook(Book book) {

        isbnIndex.put(
                book.getIsbn(),
                book
        );
    }
    // ==========================================
// SECTION D2: findByIsbn()
// ==========================================

    public Book findByIsbn(String isbn) {

        // HashMap.get() directly looks up the
        // Book using its ISBN instead of scanning
        // every book in the catalogue.
        return isbnIndex.get(isbn);
    }


    // ==========================================
    // SECTION D1: borrow()
    // ==========================================

    public boolean borrow(String isbn) {

        // HashSet.add() returns false if the
        // ISBN is already in the set.
        return currentlyBorrowed.add(isbn);
    }


    // ==========================================
    // SECTION D1: returnBook()
    // ==========================================

    public boolean returnBook(String isbn) {

        // remove() returns true if the ISBN
        // existed in the set.
        return currentlyBorrowed.remove(isbn);
    }
    // ==========================================
// SECTION D3: Most-borrowed report
// ==========================================

    public void mostBorrowedReport(String[] borrowLog) {

        HashMap<String, Integer> borrowFrequency =
                new HashMap<>();


        // Count how many times each title appears.
        for (String title : borrowLog) {

            int currentCount =
                    borrowFrequency.getOrDefault(
                            title,
                            0
                    );

            borrowFrequency.put(
                    title,
                    currentCount + 1
            );
        }


        // Find the title with the highest count.
        String mostBorrowedTitle = null;

        int highestCount = 0;

        for (String title : borrowFrequency.keySet()) {

            int count =
                    borrowFrequency.get(title);

            if (count > highestCount) {

                highestCount = count;

                mostBorrowedTitle = title;
            }
        }


        System.out.println(
                "Most-borrowed book: "
                        + mostBorrowedTitle
        );

        System.out.println(
                "Number of times borrowed: "
                        + highestCount
        );
    }
}