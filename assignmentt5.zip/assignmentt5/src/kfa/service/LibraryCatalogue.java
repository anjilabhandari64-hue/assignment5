package kfa.service;

import kfa.model.LibraryItem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class LibraryCatalogue {

    // Dynamic catalogue that can grow and shrink.
    private ArrayList<LibraryItem> catalogue;


    // Stores items that were successfully removed.
    private ArrayList<LibraryItem> removalHistory;


    // Constructor
    public LibraryCatalogue() {

        catalogue = new ArrayList<>();

        removalHistory = new ArrayList<>();
    }


    // ==========================================
    // SECTION C1: addItem()
    // ==========================================

    public void addItem(LibraryItem item) {

        catalogue.add(item);

        System.out.println(
                "Added to catalogue: "
                        + item.getTitle()
        );
    }


    // ==========================================
    // SECTION C1: removeItem()
    // ==========================================

    public boolean removeItem(String isbn) {

        for (int i = 0;
             i < catalogue.size();
             i++) {

            LibraryItem item =
                    catalogue.get(i);

            if (item.getIsbn().equals(isbn)) {

                // Save the removed item so it
                // can be restored later.
                removalHistory.add(item);

                catalogue.remove(i);

                System.out.println(
                        "Removed from catalogue: "
                                + item.getTitle()
                );

                return true;
            }
        }

        return false;
    }


    // ==========================================
    // SECTION C1: searchByTitle()
    // ==========================================

    public ArrayList<LibraryItem> searchByTitle(
            String keyword) {

        ArrayList<LibraryItem> results =
                new ArrayList<>();

        for (LibraryItem item : catalogue) {

            if (item.getTitle()
                    .toLowerCase()
                    .contains(
                            keyword.toLowerCase()
                    )) {

                results.add(item);
            }
        }

        return results;
    }


    // ==========================================
    // Helper method for testing
    // ==========================================

    public void printCatalogue() {

        for (LibraryItem item : catalogue) {

            System.out.println(item);
        }
    }
    // ==========================================
// SECTION C2: Sort by price
// ==========================================

    public void sortByPrice() {

        Collections.sort(
                catalogue,
                new Comparator<LibraryItem>() {

                    @Override
                    public int compare(
                            LibraryItem item1,
                            LibraryItem item2) {

                        return Double.compare(
                                item1.getPrice(),
                                item2.getPrice()
                        );
                    }
                }
        );
    }


// ==========================================
// SECTION C2: Sort by title
// ==========================================

    public void sortByTitle() {

        Collections.sort(
                catalogue,
                new Comparator<LibraryItem>() {

                    @Override
                    public int compare(
                            LibraryItem item1,
                            LibraryItem item2) {

                        return item1.getTitle()
                                .compareToIgnoreCase(
                                        item2.getTitle()
                                );
                    }
                }
        );
    }
    // ==========================================
// SECTION C3: undoRemove()
// ==========================================

    public void undoRemove() {

        // Check whether there is anything to undo.
        if (removalHistory.isEmpty()) {

            System.out.println(
                    "Nothing to undo."
            );

            return;
        }


        // Get the most recently removed item.
        int lastIndex =
                removalHistory.size() - 1;

        LibraryItem item =
                removalHistory.get(lastIndex);


        // Add it back to the catalogue.
        catalogue.add(item);


        // Remove it from the history.
        removalHistory.remove(lastIndex);


        System.out.println(
                "Undo successful. Restored: "
                        + item.getTitle()
        );
    }
}